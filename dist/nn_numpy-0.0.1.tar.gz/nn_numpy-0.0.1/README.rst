Neural Networks from scratch with Numpy
=======================================

Introduction
------------

Neural Networks
~~~~~~~~~~~~~~~

Some videos to watch and understanding the theory behind Neural
Networks.

-  `But what is a Neural Network? \| Deep learning, chapter 1`_

-  `Gradient descent, how neural networks learn \| Deep learning,
   chapter 2`_

-  `What is backpropagation really doing? \| Deep learning, chapter 3`_

-  `Backpropagation calculus \| Deep learning, chapter 4`_

Instalation
-----------

Contributing
------------

Thanks
------

.. _But what is a Neural Network? \| Deep learning, chapter 1: https://www.youtube.com/watch?v=aircAruvnKk
.. _Gradient descent, how neural networks learn \| Deep learning, chapter 2: https://www.youtube.com/watch?v=IHZwWFHWa-w
.. _What is backpropagation really doing? \| Deep learning, chapter 3: https://www.youtube.com/watch?v=Ilg3gGewQ5U
.. _Backpropagation calculus \| Deep learning, chapter 4: https://www.youtube.com/watch?v=tIeHLnjs5U8